from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired, Length

class BookForm(FlaskForm):
    title = StringField('title', validators=[DataRequired(), Length(max=100)])
    author = StringField('author', validators=[DataRequired(), Length(max=100)])

# Step 1: Define the data structure
contacts = []

# Step 2: Create functions for add, view, update, and delete

def add_contact():
    name = input("Enter contact name: ")
    phone = input("Enter phone number: ")
    email = input("Enter email address: ")
    contacts.append({'name': name, 'phone': phone, 'email': email})
    print("Contact added successfully.")

def view_contacts():
    if not contacts:
        print("No contacts found.")
    else:
        for idx, contact in enumerate(contacts, start=1):
            print(f"\nContact {idx}:")
            print(f"Name: {contact['name']}")
            print(f"Phone: {contact['phone']}")
            print(f"Email: {contact['email']}")
    print()

def update_contact():
    name = input("Enter the name of the contact to update: ")
    for contact in contacts:
        if contact['name'] == name:
            phone = input("Enter new phone number (leave blank to keep current): ")
            email = input("Enter new email address (leave blank to keep current): ")
            if phone:
                contact['phone'] = phone
            if email:
                contact['email'] = email
            print("Contact updated successfully.")
            return
    print("Contact not found.")

def delete_contact():
    name = input("Enter the name of the contact to delete: ")
    for contact in contacts:
        if contact['name'] == name:
            contacts.remove(contact)
            print("Contact deleted successfully.")
            return
    print("Contact not found.")

# Step 3: Create a menu

def display_menu():
    print("\nContact Book Menu:")
    print("1. Add a contact")
    print("2. View contacts")
    print("3. Update a contact")
    print("4. Delete a contact")
    print("5. Exit")

# Step 4, 5, and 6: Implement the functionality for each action with error handling and a loop

def contact_book_app():
    while True:
        display_menu()
        choice = input("Enter choice: ")

        if choice == '1':
            add_contact()
        elif choice == '2':
            view_contacts()
        elif choice == '3':
            update_contact()
        elif choice == '4':
            delete_contact()
        elif choice == '5':
            print("Exiting the contact book!")
            break
        else:
            print("Invalid choice! Please select a valid option.")

contact_book_app()
